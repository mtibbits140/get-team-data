<?php	
	/*
   Plugin Name: Get Team Data
   Plugin URI: 
   Description: test plugin for Chalk job application
   Version: 0.9
   Author: Matt Tibbits
   Author URI: http://tibbits.ca
   License: GPL2
   */
   
   	class getTeamData {		
		
		protected $url;
		protected $timeout;
		protected $json;
		protected $data;
		public $teams;
		
		//constructor method
		public function __construct($url, $timeout) {
			$this->url = $url;
			$this->timeout = $timeout;
			
			add_shortcode('GetTeamData', array($this, 'shortcode'));
		}
		
		//return data from data source (URL) using cURL			
		public function getWithCurl() {
					
			$c = curl_init();
			
			curl_setopt($c, CURLOPT_URL, $this->url);
			curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($c, CURLOPT_CONNECTTIMEOUT, $this->timeout);
			
			$this->json = curl_exec($c);
			curl_close($c);						
			return $this->json;
		}
		
		//convert JSON format
		public function decodeJson() {
			$this->getWithCurl();
			$this->data = json_decode($this->json);
			return $this->data;
		}
		
		//sort data 
		public function getSortedData() {
			
			$this->data = $this->decodeJson();
			$this->teams = $this->data->results->data->team;
				
			$conferences = array();
			$i = 0;
			foreach ($this->teams as $team) {
				$conferences[] = $this->teams[$i]->conference;
				$i++;
			}
			
			$divisions = array();
			$i = 0;
			foreach ($this->teams as $team) {
				$divisions[] = $this->teams[$i]->division;
				$i++;
			}
			
			array_multisort($conferences, SORT_ASC, SORT_REGULAR, $divisions, $this->teams);	
			
			return $this->teams;			
		}	
		
		//display data
		public function displayData() {
			
			//set flags to zero
			$confFlag = NULL;
			$divFlag = NULL;
			$html[] = '<div class="teams">';
			
			for ($i=0; $i < count($this->teams); $i++) {
				
				//if conference flag is not set
				if ($confFlag == NULL) {
					
					//set conference flag
					$confFlag = $this->teams[$i]->conference;
					
					//display current conf
					$html[] = '<h1>' . $this->teams[$i]->conference . '</h1>';
					
				} elseif ($confFlag !== $this->teams[$i]->conference) {	
					//check if conference has changed
					 //set conference flag
					$confFlag = $this->teams[$i]->conference;
					
					//display current conf
					$html[] = '<h1>' . $this->teams[$i]->conference . '</h1>';
				} 
				
				//if division flag is not set
				if ($divFlag == NULL) {
					
					//set division flag
					$divFlag = $this->teams[$i]->division;
					
					//display current division
					$html[] = '<h3>' . $this->teams[$i]->division . '</h3>';
					
				} elseif ($divFlag !== $this->teams[$i]->division) {	
					//check if division has changed
					 //set division flag
					$divFlag = $this->teams[$i]->division;
					
					//display current div
					$html[] = '<h3>' . $this->teams[$i]->division . '</h3>';
				} 
			
				//display team name	
				$html[] = $this->teams[$i]->name . '<br>';
			}
			$html[] = '</div>';
			return implode("\n", $html);
			
		}
		
		
		//setup shortcode
		public function shortcode() {
			$this->getSortedData();
			return $this->displayData();
		}
		
		
	}
	
		
	
	$url = 'http://delivery.chalk247.com/team_list/NFL.JSON?api_key=74db8efa2a6db279393b433d97c2bc843f8e32b0';
	
	//instantiate getData class
	$myChalkDataObj = new getTeamData($url, 5);	

?>

